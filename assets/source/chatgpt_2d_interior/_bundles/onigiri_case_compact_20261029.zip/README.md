# おにぎり用冷蔵陳列ケース — FULL (ChatGPT ImageGen 2D illustration)

**Image classification verified:** Japanese triangular packaged rice balls in an open-front refrigerated display unit (not cup noodles).

- `source_original.png` — unmodified 1536×1024 RGBA master
- `source_fullres.webp` — high-quality full-resolution alternative
- `game_512.png`, `game_256.png` — lower-resolution previews, same asset
- `manifest.json` — world scale / intended projection / approval status

The image is a *visual candidate*. The apparent long shelf edge slopes right/down, which may not match r0 world +X long face (screen slope −0.5); Codex must inspect and correct by regenerating the artwork if necessary, **not by mirroring product labels or distorting pixels**.
Game screen zoom, placement anchors and footprint 1×2 tiles are not yet verified. `runtime_approved: false` until human QA and Godot screenshots pass.
