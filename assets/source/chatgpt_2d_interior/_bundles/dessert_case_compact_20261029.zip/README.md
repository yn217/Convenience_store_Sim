# デザート冷蔵ケース FULL — コンパクト配布パック

このZIPには`source_fullres.webp`、`game_512.png`、`game_256.png`、manifest、READMEが含まれます。
元の1536×1024 PNGはZIP内には含めず、PR #164の次のリポジトリパスに原本のまま保存しています。

`assets/source/chatgpt_2d_interior/shelf_dessert_chatgpt_20261029_v1/source_original.png`
SHA-256: `819cdf41da617dd1f5eb5ca369533714798adf3e8bc4054ef5f4799378f13b4d`

この画像は未承認のFULL候補です。`iso2x_v1`投影、実寸、footprint、地面アンカー、透明縁、Godot実表示は未検証です。
商品や什器を変形して整合を装わず、`runtime_approved:false`を維持してください。
