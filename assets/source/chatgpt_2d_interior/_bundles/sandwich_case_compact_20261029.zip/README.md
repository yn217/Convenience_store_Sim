# 日本のコンビニ：サンドイッチ冷蔵陳列ケース FULL（未承認）

ホットスナック加温ケースとして画像生成しましたが、実際は**サンドイッチ・惣菜パン陳列ケース**です。正しい種類で保存し、ホットスナックとして流用しないでください。

- `source_original.png`: 生成原画1536×1024（変更せず保存）
- `source_fullres.webp`: 原寸の高画質版
- `game_512.png` / `game_256.png`: ゲーム用縮小LOD（設備グレードを意味しません）
- `manifest.json`: 実際の商品分類、投影、QA/採用状態

`iso2x_v1`のゲーム投影、客側+X、実world footprint、ground anchor、商品正面、背景透過と輪郭をCodexが測定してください。`runtime_approved:false`のまま保管します。